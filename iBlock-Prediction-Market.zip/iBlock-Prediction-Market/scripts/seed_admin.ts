/**
 * ONE-TIME admin burner account (additive; safe to re-run).
 *
 * Creates a role="admin" account for the operator (Sam) that is NOT part of the
 * student rotation (rotationGroup = null), so it always keeps teacher/admin
 * access and is never touched by /users/rotation/activate.
 *
 * This is SEPARATE from Sam's student account (ss196), which Sam self-registers
 * from the roster and plays normally.
 *
 * Prints a random temp password once — log in with it, then immediately change
 * it via POST /auth/change-password (or the change-password UI).
 *
 * Override the handle if you like:
 *   ADMIN_USERNAME=sam_admin node --experimental-strip-types .../scripts/src/seed_admin.ts
 */
import { db, usersTable } from "@workspace/db";
import crypto from "crypto";

// Inlined to match scripts/src/seed.ts (avoids fragile cross-package import).
function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password + "ibpm-salt-2025").digest("hex");
}

const USERNAME = process.env.ADMIN_USERNAME || "sam_admin";
const DISPLAY_NAME = process.env.ADMIN_DISPLAY || "Sam (Admin)";

function tempPassword(): string {
  return `ibpm-admin-${crypto.randomBytes(4).toString("hex")}`;
}

async function main() {
  const users = await db.select().from(usersTable);
  if (users.find((u) => u.username === USERNAME)) {
    console.log(`Admin account "${USERNAME}" already exists — leaving it untouched.`);
    console.log(`If you need a new password, use the teacher reset endpoint or the Admin page.`);
    process.exit(0);
  }

  const pw = tempPassword();
  const [created] = await db
    .insert(usersTable)
    .values({
      username: USERNAME,
      displayName: DISPLAY_NAME,
      email: null,
      passwordHash: hashPassword(pw),
      role: "admin",
      cohortId: null,
      rotationGroup: null,
      giesBalance: "1000",
    })
    .returning();

  console.log("========================================");
  console.log(" Admin burner created");
  console.log(`   username: ${created.username}`);
  console.log(`   role:     ${created.role}`);
  console.log(`   TEMP PW:  ${pw}`);
  console.log(" Log in, then change this password immediately.");
  console.log("========================================");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
