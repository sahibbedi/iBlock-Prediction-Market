---
name: Badge evaluation pattern
description: How badges are defined, evaluated, and wired into routes
---

Badge definitions are hardcoded in `artifacts/api-server/src/lib/badges.ts`.
The `evaluateAndAwardBadges(userId)` helper runs all badge checks in one call and inserts newly earned badges.

**Why:** Centralised evaluation avoids scattered award logic; fire-and-forget (`.catch(console.error)`) means it never blocks the response.

**How to apply:** Add `evaluateAndAwardBadges(req.user!.id).catch(console.error);` before the final `res.json()` in any route where a badge-relevant action happens (trade, idea, vote, comment, liquidity). Already hooked into: trades.ts (buy+sell), ideas.ts (create+vote), comments.ts (create), liquidity.ts (provide).
